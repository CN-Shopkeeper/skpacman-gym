from skpacman_gym.envs.skpacman import SKPacmanEnv
