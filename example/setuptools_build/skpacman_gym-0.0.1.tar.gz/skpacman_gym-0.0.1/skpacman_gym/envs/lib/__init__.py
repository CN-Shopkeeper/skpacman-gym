import  os

current_directory = os.path.dirname(os.path.abspath(__file__))